package com.cts.authenticationservice.request;

import com.cts.authenticationservice.utils.ValidEmail;
import com.cts.authenticationservice.utils.ValidPassword;

import lombok.Data;

@Data
public class UserDetailRequest {

	private int userId;
	private String userName;
	private String address;
	private String phone;
	@ValidEmail
	private String email;
	@ValidPassword
	private String password;
	private boolean isEnabled;
	private String verificationToken;

}
