package com.cts.authenticationservice.service;

import java.io.UnsupportedEncodingException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.authenticationservice.dto.AuthenticationRequest;
import com.cts.authenticationservice.dto.AuthenticationResponse;
import com.cts.authenticationservice.dto.UserDetail;
import com.cts.authenticationservice.repo.UserDetailRepository;
import com.cts.authenticationservice.request.UserDetailRequest;
import com.cts.authenticationservice.security.JWTTokenProvider;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class UserAuthenticationImpl implements UserAuthenticationService {

	@Autowired
	private UserDetailRepository userDetailRepository;

	@Autowired
	private JavaMailSender mailSender;

	@Override
	public ResponseEntity<?> addUser(UserDetailRequest userDetailRequest) {

		try {
			if (userDetailRepository.existsByEmail(userDetailRequest.getEmail())) {
				return ResponseEntity.badRequest().body("Error: Email already exists");
			}

			UserDetail user = getUserData(userDetailRequest);

			String confirmationToken = UUID.randomUUID().toString();
			user.setVerificationToken(confirmationToken);

			user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));

			userDetailRepository.save(user);

			sendVerificationEmail(user, confirmationToken);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		}

		return ResponseEntity.ok("Message : Registration successful. Verification email sent");

	}

	private UserDetail getUserData(UserDetailRequest userDetailRequest) {
		UserDetail user = new UserDetail();
		user.setUserId(userDetailRequest.getUserId());
		user.setUserName(userDetailRequest.getUserName());
		user.setAddress(userDetailRequest.getAddress());
		user.setEmail(userDetailRequest.getEmail());
		user.setEnabled(userDetailRequest.isEnabled());
		user.setPassword(userDetailRequest.getPassword());
		user.setPhone(userDetailRequest.getPhone());
		user.setVerificationToken(userDetailRequest.getVerificationToken());
		return user;
	}

	@Override
	public ResponseEntity<?> confirmEmail(String verificationToken) {
		UserDetail token = userDetailRepository.findByVerificationToken(verificationToken);

        if(token != null){
        	UserDetail user = userDetailRepository.findByEmailIgnoreCase(token.getEmail());
            user.setEnabled(true);
            userDetailRepository.save(user);
            return ResponseEntity.ok("Email verified successfully!");
        } 
        return ResponseEntity.badRequest().body("Invalid Link or Link got Expired ");
    }
	
	private void sendVerificationEmail(UserDetail user, String verificationCode)
	        throws MessagingException, UnsupportedEncodingException {
	    String toAddress = user.getEmail();
	    String fromAddress = "kavitacj19@gmail.com";
	    String senderName = "KAV";
	    String subject = "Complete Registration";
	    String content = "To confirm your account, please click here : "
	    		+ "http://localhost:8082/api/confirm-account?token="+verificationCode;
	     
	    MimeMessage message = mailSender.createMimeMessage();
	    MimeMessageHelper helper = new MimeMessageHelper(message);
	     
	    helper.setFrom(fromAddress, senderName);
	    helper.setTo(toAddress);
	    helper.setSubject(subject);
	     
	    helper.setText(content, true);
	     
	    mailSender.send(message);
	     
	}

	@Override
	public ResponseEntity<?> loginUser(AuthenticationRequest userInfo) {
		AuthenticationResponse response = new AuthenticationResponse();
		try {
			Optional<UserDetail> userDetails = userDetailRepository.findByEmail(userInfo.getUserEmail());
			if(userDetails.isPresent()) {
				UserDetail userDetail = userDetails.get();
				if(isPasswordMatches(userInfo.getPassword(), userDetail.getPassword())) {
					LocalDateTime ldt = LocalDateTime.now().plusMinutes(15);
					response.setAccessToken(new JWTTokenProvider(userDetail.getEmail(), userDetail.getPassword(), ldt.toEpochSecond(ZoneOffset.UTC)).toString());
					response.setMessage("Login Successfull.");
				} else {
					response.setError("Login Failed, Invalid Pasword. Please try again later");
					return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);	
				}
			} else {
				response.setError("Login Failed, user doesnt exists. Please try again later");
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
	}

	
	private boolean isPasswordMatches(String password, String encodedPwd) {
		BCryptPasswordEncoder encryptor = new BCryptPasswordEncoder();
		return encryptor.matches(password, encodedPwd);
	}

}
