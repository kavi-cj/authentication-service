package com.cts.authenticationservice.service;

import java.io.UnsupportedEncodingException;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.authenticationservice.dto.UserDetail;
import com.cts.authenticationservice.repo.UserDetailRepository;
import com.cts.authenticationservice.request.UserDetailRequest;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class UserAuthenticationImpl implements UserAuthenticationService {

	@Autowired
	private UserDetailRepository userDetailRepository;

	@Autowired
	private JavaMailSender mailSender;

	@Override
	public ResponseEntity<?> addUser(UserDetailRequest userDetailRequest) {

		try {
			if (userDetailRepository.existsByEmail(userDetailRequest.getEmail())) {
				return ResponseEntity.badRequest().body("Error: Email already exists");
			}

			UserDetail user = getUserData(userDetailRequest);

			String confirmationToken = UUID.randomUUID().toString();
			user.setVerificationToken(confirmationToken);

			user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));

			userDetailRepository.save(user);

			sendVerificationEmail(user, confirmationToken);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		}

		return ResponseEntity.ok("Message : Registration successful. Verification email sent");

	}

	private UserDetail getUserData(UserDetailRequest userDetailRequest) {
		UserDetail user = new UserDetail();
		user.setUserId(userDetailRequest.getUserId());
		user.setUserName(userDetailRequest.getUserName());
		user.setAddress(userDetailRequest.getAddress());
		user.setEmail(userDetailRequest.getEmail());
		user.setEnabled(userDetailRequest.isEnabled());
		user.setPassword(userDetailRequest.getPassword());
		user.setPhone(userDetailRequest.getPhone());
		user.setVerificationToken(userDetailRequest.getVerificationToken());
		return user;
	}

	@Override
	public ResponseEntity<?> confirmEmail(String verificationToken) {
		UserDetail token = userDetailRepository.findByVerificationToken(verificationToken);

        if(token != null){
        	UserDetail user = userDetailRepository.findByEmailIgnoreCase(token.getEmail());
            user.setEnabled(true);
            userDetailRepository.save(user);
            return ResponseEntity.ok("Email verified successfully!");
        } 
        return ResponseEntity.badRequest().body("Invalid Link or Link got Expired ");
    }
	
	private void sendVerificationEmail(UserDetail user, String verificationCode)
	        throws MessagingException, UnsupportedEncodingException {
	    String toAddress = user.getEmail();
	    String fromAddress = "kavitacj19@gmail.com";
	    String senderName = "KAV";
	    String subject = "Complete Registration";
	    String content = "To confirm your account, please click here : "
	    		+ "http://localhost:8082/api/confirm-account?token="+verificationCode;
	     
	    MimeMessage message = mailSender.createMimeMessage();
	    MimeMessageHelper helper = new MimeMessageHelper(message);
	     
	    helper.setFrom(fromAddress, senderName);
	    helper.setTo(toAddress);
	    helper.setSubject(subject);
	     
	    helper.setText(content, true);
	     
	    mailSender.send(message);
	     
	}

}
