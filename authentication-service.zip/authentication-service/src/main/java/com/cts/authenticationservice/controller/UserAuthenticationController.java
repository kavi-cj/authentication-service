package com.cts.authenticationservice.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.authenticationservice.dto.AuthenticationRequest;
import com.cts.authenticationservice.request.UserDetailRequest;
import com.cts.authenticationservice.service.UserAuthenticationService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api")
public class UserAuthenticationController {

	@Autowired
	private UserAuthenticationService userAuthenticationService;
	
	@PostMapping("/register")
	public ResponseEntity<?> registerUser(@RequestBody @Valid UserDetailRequest userDetail){
		try {
		return userAuthenticationService.addUser(userDetail);
		} catch (Exception e) {
			e.printStackTrace();
			Map<String, String> map = new HashMap<String, String>();
			map.put("error", "Message: Registration Failed. Please Try Again Later");
			map.put("message", e.getMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(map);
		}
	}
	
	@RequestMapping(value="/confirm-account", method= {RequestMethod.GET, RequestMethod.POST})
    public ResponseEntity<?> confirmUserAccount(@RequestParam("token")String confirmationToken) {
        return userAuthenticationService.confirmEmail(confirmationToken);
    }
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody AuthenticationRequest userInfo){
		try {
			return userAuthenticationService.loginUser(userInfo);
		} catch (Exception e) { 
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid Input");
		}
	}


}
