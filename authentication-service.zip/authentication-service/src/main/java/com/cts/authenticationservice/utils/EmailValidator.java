package com.cts.authenticationservice.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class EmailValidator implements ConstraintValidator<ValidEmail, String> {

	public boolean isValid(String value, ConstraintValidatorContext context) {
		if (value == null || value.isEmpty() || !pattern(value))
			return false;
		return true;
	}

	private boolean pattern(String value) {
		String regex = "^(.+)@(.+)$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(value);

		return matcher.matches();
	}
}