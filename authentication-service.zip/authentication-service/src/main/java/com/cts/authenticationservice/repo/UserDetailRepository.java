package com.cts.authenticationservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.authenticationservice.dto.UserDetail;

public interface UserDetailRepository extends JpaRepository<UserDetail, Integer> {

	boolean existsByEmail(String email);

	UserDetail findByEmailIgnoreCase(String email);

	UserDetail findByVerificationToken(String verificationToken);

}
