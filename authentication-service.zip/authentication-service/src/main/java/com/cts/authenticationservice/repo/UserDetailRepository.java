package com.cts.authenticationservice.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.authenticationservice.dto.UserDetail;

public interface UserDetailRepository extends JpaRepository<UserDetail, Integer> {

	boolean existsByEmail(String email);

	UserDetail findByEmailIgnoreCase(String email);

	UserDetail findByVerificationToken(String verificationToken);

	Optional<UserDetail> findByEmail(String email);

}
