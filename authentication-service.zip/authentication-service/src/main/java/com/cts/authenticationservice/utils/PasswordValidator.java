package com.cts.authenticationservice.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class PasswordValidator implements ConstraintValidator<ValidPassword, String> {

	public boolean isValid(String value, ConstraintValidatorContext context) {
		if (value == null || value.isEmpty() || !pattern(value))
			return false;
		return true;
	}

	private boolean pattern(String value) {
		String regex = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(value);

		return matcher.matches();
	}

}