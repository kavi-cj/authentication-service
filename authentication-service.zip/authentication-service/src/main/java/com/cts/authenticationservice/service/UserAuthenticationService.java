package com.cts.authenticationservice.service;

import org.springframework.http.ResponseEntity;

import com.cts.authenticationservice.dto.AuthenticationRequest;
import com.cts.authenticationservice.request.UserDetailRequest;

public interface UserAuthenticationService {

	public ResponseEntity<?> addUser(UserDetailRequest userDetail);
	
    public ResponseEntity<?> confirmEmail(String verificationToken);
    
    public ResponseEntity<?> loginUser(AuthenticationRequest userInfo);
    
    

}
